import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:zkfinger1/pages/enroll_biometrics_page.dart';

import 'enums/page_step_enum.dart';
import 'pages/connect_device_page.dart';
import 'pages/verify_user_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
//You can request multiple permissions at once.
  Map<Permission, PermissionStatus> statuses = await [
    Permission.camera,
    Permission.storage,
    Permission.photos
  ].request();
  print("PERMISSIONS::${statuses[Permission.storage]}");
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  static const platform = MethodChannel('abc');
  String _responseFromNativeCode = 'Waiting for Response...';
  Future<void> start() async {
    String response = "";
    try {
      final String result = await platform.invokeMethod('start');
      response = result;
    } on PlatformException catch (e) {
      response = "Failed to Invoke: '${e.message}'.";
    }
    setState(() {
      _responseFromNativeCode = response;
    });
  }

  late PageStep pageStep;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    pageStep = PageStep.CONNECT_DEVICE;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: const [
            Row(
              children: [
                Text("No Device Connected",
                    style: TextStyle(color: Colors.grey))
              ],
            ),
            SizedBox(
              width: 50,
            ),
          ],
          centerTitle: true,
          title: const Text(
            "Native Code Integration to Flutter ",
            style: TextStyle(color: Colors.orange),
          )),
      body: (pageStep == PageStep.CONNECT_DEVICE)
          ? ConnectDevicePage(
              nextPage: () {
                setState(() {
                  pageStep = PageStep.ENTER_USER;
                });
              },
            )
          : (pageStep == PageStep.ENTER_USER)
              ? VerifyUserPage(
                  onNextPage: () {
                    setState(() {
                      pageStep = PageStep.ENTER_BIOMETRICS;
                    });
                  },
                )
              : (pageStep == PageStep.ENTER_BIOMETRICS)
                  ? EnrollBiometricsPage(
                      onNextPage: () {
                        setState(() {
                          pageStep = PageStep.VERIFY_BIOMETRICS;
                        });
                      },
                    )
                  : Container(),
    );
  }
}
